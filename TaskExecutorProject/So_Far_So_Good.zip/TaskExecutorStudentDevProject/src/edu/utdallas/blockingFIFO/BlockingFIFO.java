package edu.utdallas.blockingFIFO;
import edu.utdallas.taskExecutor.Task;
public interface BlockingFIFO {
	Task buffer[];
	int nextin, nextout;
	int count;
	Object notfull, notempty; // Monitors used for synchronization

	void put(Task task);

	Task take();

}
